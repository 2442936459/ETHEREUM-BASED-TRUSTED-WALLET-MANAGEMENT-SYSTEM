App = {
  provider: null,
  cancelScrypt: false,
  activeWallet: null,
  contract: null,

  setupWallet: function (wallet) {
    showWallet();

    //使用 Provider 连接以太坊网络
    App.provider = new ethers.providers.JsonRpcProvider("http://127.0.0.1:7545");

    // App.provider = ethers.getDefaultProvider('ropsten');

    // wallet 为之前导入或者生成的钱包对象, activeWallet就是后面可以用来请求余额发送交易的对象
    App.activeWallet = wallet.connect(App.provider);

    var inputWalletAddress = $('#wallet-address');
    inputWalletAddress.val(wallet.address);


    // 点击导出 keystore 按钮后，与 exportKeystore 函数，即导出keystore文件函数绑定在一起
    $('#save-keystore').click(App.exportKeystore);
    // 导出助记词
    $('#save-mnemonic').click(App.exportMnemonic);
    // 查看助记词
    $('#look-mnemonic').click(App.look_Mnemonic);
    // 导出私钥
    $('#save-privateKey').click(App.exportprivateKey);
    // 查看私钥
    $('#look-privateKey').click(App.look_privateKey);




    App.setupSendEther();
    App.refreshUI();

    App.initToken();
    App.setupSendToken();
  },

  init: function () {
    App.initLoadJson();
    App.initLoadKey();
    App.initMnemonic();
  },

  updateLoading: function (progress) {
    console.log(progress);
    $("#loading-status").val(parseInt(progress * 100) + '%');
    return App.cancelScrypt;
  },

  initLoadJson: function () {
    // keystore 恢复生成
    setupDropFile(function (json, password) {
      if (ethers.utils.getJsonWalletAddress(json)) {
        showLoading('解密账号...');
        App.cancelScrypt = false;

        ethers.Wallet.fromEncryptedJson(json, password, App.updateLoading).then(function (wallet) {
          App.setupWallet(wallet);
        }, function (error) {
          if (error.message === 'invalid password') {
            alert('Wrong Password');
          } else {
            alert('解密账号发生错误...');
            console.log(error);
          }
          showAccout();
        });
      } else {
        alert('Unknown JSON wallet format');
      }
    });
  },

  // 页面： 私钥管理->加载私钥
  // 创建钱包账号
  // 使用随机数作为私钥创建钱包账号
  initLoadKey: function () {
    // 使用JQuery获取两个UI标签
    var inputPrivatekey = $('#select-privatekey');
    var submit = $('#select-submit-privatekey');

    // 生成一个默认的私钥
    let randomNumber = ethers.utils.bigNumberify(ethers.utils.randomBytes(32));
    inputPrivatekey.val(randomNumber._hex);

    submit.click(function () {
      if (submit.hasClass('disable')) { return; }
      var privateKey = inputPrivatekey.val();
      if (privateKey.substring(0, 2) !== '0x') { privateKey = '0x' + privateKey; }

      // 创建对应的钱包
      App.setupWallet(new ethers.Wallet(privateKey));

    });

    inputPrivatekey.on("input", function () {
      if (inputPrivatekey.val().match(/^(0x)?[0-9A-fa-f]{64}$/)) {
        submit.removeClass('disable');
      } else {
        submit.addClass('disable');
      }
    });

  },


  // 创建钱包账号
  // 通过助记词方式创建钱包账号
  initMnemonic: function () {
    // 生成的助记词
    var inputPhrase = $('#select-mnemonic-phrase');
    var inputPath = $('#select-mnemonic-path');
    var submit = $('#select-submit-mnemonic');

    // 生成助记词
    // mnemonic 为 12 个 单词
    var mnemonic = ethers.utils.HDNode.entropyToMnemonic(ethers.utils.randomBytes(16));
    // alert(mnemonic);
    // 在输入框中加入单词
    inputPhrase.val(mnemonic);

    function check() {
      // 如果 助记词的输入框中 inputPhrase 并非有效的助记词，提交（推导）键失效
      if (ethers.utils.HDNode.isValidMnemonic(inputPhrase.val())) {
        submit.removeClass('disable');
      } else {
        submit.addClass('disable');
      }
    }
    inputPhrase.on("input", check);

    // 此句暂时失效
    inputPath.on("input", check);

    // 点击 推导 按钮，如果 推导 按钮未失效，按照助记词创建钱包
    submit.click(function () {
      if (submit.hasClass('disable')) { return; }
      alert("请牢记助记词,将其记在安全的地方,切勿截图");
      App.setupWallet(ethers.Wallet.fromMnemonic(inputPhrase.val(), inputPath.val()));
    });

  },

  // 导出 Keystore 文件
  exportKeystore: function () {
    // 获取密码
    var pwd = $('#save-keystore-file-pwd');

    showLoading('导出keystore文件...');
    App.cancelScrypt = false;

    App.activeWallet.encrypt(pwd.val(), App.updateLoading).then(function (json) {
      showWallet();
      var blob = new Blob([json], { type: "text/plain;charset=utf-8" });
      // 使用了FileSaver.js 进行文件保存
      saveAs(blob, "keystore.json");

    });
  },


  // 导出 助记词 文件
  exportMnemonic: function () {
    // 获取密码
    var pwd = $('#save-mnemonic-file-pwd');

    showLoading('导出助记词...');
    App.cancelScrypt = false;

    //获取助记词   App.activeWallet.mnemonic
    // var mnemonic = App.activeWallet.privateKey;
    // alert(mnemonic);
    //  console.log("钱包助记词：",mnemonic)

    App.activeWallet.encrypt(pwd.val(), App.updateLoading).then(function (json) {
      showWallet();
      var blob = new Blob([json], { type: "text/plain;charset=utf-8" });
      // 使用了FileSaver.js 进行文件保存
      saveAs(blob, "mnemonic.json");
    });

  },


  // 查看 助记词 
  look_Mnemonic: function () {
    // 获取密码
    var pwd = $('#save-mnemonic-file-pwd');

    // showLoading('查看助记词...');
    App.cancelScrypt = false;

    //获取助记词   App.activeWallet.mnemonic
    var mnemonic = App.activeWallet.mnemonic;
    // alert(mnemonic);
    //  console.log("钱包助记词：",mnemonic)

    // 在输入框中加入单词
    pwd.val(mnemonic);
  },

  // 导出 私钥 文件
  exportprivateKey: function () {
    // 获取密码
    var pwd = $('#save-privateKey-file-pwd');

    showLoading('导出私钥文件...');
    App.cancelScrypt = false;

    //获取助记词   App.activeWallet.mnemonic
    // var privateKey = App.activeWallet.privateKey;
    // alert(privateKey);
    //  console.log("钱包助记词：",mnemonic)

    App.activeWallet.encrypt(pwd.val(), App.updateLoading).then(function (json) {
      showWallet();
      var blob = new Blob([json], { type: "text/plain;charset=utf-8" });
      // 使用了FileSaver.js 进行文件保存
      saveAs(blob, "privateKey.json");
    });

  },


  // 查看 私钥 
  look_privateKey: function () {
    // 获取密码
    var pwd = $('#save-privateKey-file-pwd');

    // showLoading('查看私钥...');
    App.cancelScrypt = false;

    //获取助记词   App.activeWallet.mnemonic
    var privateKey = App.activeWallet.privateKey;
    // alert(mnemonic);
    //  console.log("钱包助记词：",mnemonic)

    // 在输入框中加入单词
    pwd.val(privateKey);
  },


  // 展示交易信息
  refreshUI: function () {
    // 余额
    var inputBalance = $('#wallet-balance');
    // 交易次数
    var inputTransactionCount = $('#wallet-transaction-count');

    // 防止一次点击多次响应
    // $('#bt').unbind().click(function(){...});

    // 刷新
    $("#wallet-submit-refresh").unbind().click(function () {
      App.addActivity('> --------Refreshing details--------');
      // 获取余额， 包含当前正在打包的区块
      App.activeWallet.getBalance('pending').then(function (balance) {
        // 余额
        App.addActivity('< Balance: ' + balance.toString(10));
        // 单位转换 wei -> ether
        inputBalance.val(ethers.utils.formatEther(balance, { commify: true }));
      }, function (error) {
        showError(error);
      });

      // 展示交易信息
      // 交易次数
      App.activeWallet.getTransactionCount('pending').then(function (transactionCount) {
        App.addActivity('< TransactionCount: ' + transactionCount);
        inputTransactionCount.val(transactionCount);
      }, function (error) {
        showError(error);
      });
    });

    // 模拟一次点击获取数据
    $("#wallet-submit-refresh").click();

  },
           

  initToken: function () {

    $.getJSON('TutorialToken.json', function (data) {
      // 智能合约地址
      const address = data.networks["5777"].address;
      console.log(address);

      // 创建智能合约
      App.contract = new ethers.Contract(address, data.abi, App.provider);

      // const contract = web3.eth.contract(data.abi).at(address);
      // contract.transfer.estimateGas("0x627306090abaB3A6e1400e9345bC60c78a8BEf57", 1, {from: App.activeWallet.address}, function (gas) {
      //   console.log("gas:" + gas);
      // });

      console.log("contract:" + App.contract);

      App.refreshToken();
    });
  },

  // 更新代币余额 ERC20 TOKEN
  refreshToken: function () {
    // ERC20 TOKEN 余额
    var tokenBalance = $('#wallet-token-balance');
    // 直接调用合约方法
    App.contract.balanceOf(App.activeWallet.address).then(function (balance) {
      tokenBalance.val(balance);
    });
  },

  addActivity: function (message) {
    var activity = $('#wallet-activity');
    activity.append("</br>" + message);
  },

  setupSendEther: function () {
    // 以太转账 地址
    var inputTargetAddress = $('#wallet-send-target-address');
    // 以太转账 金额
    var inputAmount = $('#wallet-send-amount');
    // 发送 按钮
    var submit = $('#wallet-submit-send');

    // 检查地址和金额是否正确
    // Validate the address and value (to enable the send button)
    function check() {
      try {
        ethers.utils.getAddress(inputTargetAddress.val());
        ethers.utils.parseEther(inputAmount.val());
      } catch (error) {
        submit.addClass('disable');
        return;
      }
      submit.removeClass('disable');
    }

    inputTargetAddress.on("input", check);
    inputAmount.on("input", check);

    // Send ether
    // 发送以太 用ethers.js 实现发送交易
    submit.click(function () {
      // 得到一个checksum 地址
      var targetAddress = ethers.utils.getAddress(inputTargetAddress.val());
      /// ether -> wei
      var amountWei = ethers.utils.parseEther(inputAmount.val());


      // 构造交易
      App.activeWallet.sendTransaction({
        to: targetAddress,
        value: amountWei,
        //gasPrice: activeWallet.provider.getGasPrice(),
        //gasLimit: 21000,
      }).then(function (tx) {
        console.log(tx);

        App.refreshUI();
        App.addActivity('< To: ' + targetAddress.toString());
        App.addActivity('< TXID: ' + tx.hash.substring(0, 100) );
        alert('Success!');

        inputTargetAddress.val('');
        inputAmount.val('');
        submit.addClass('disable');

        
      }, function (error) {
        console.log(error);
        showError(error);
      });
    })
  },


  setupSendToken: function () {
    var inputTargetAddress = $('#wallet-token-send-target-address');
    var inputAmount = $('#wallet-token-send-amount');
    var submit = $('#wallet-token-submit-send');

    // Validate the address and value (to enable the send button)
    function check() {
      try {
        ethers.utils.getAddress(inputTargetAddress.val());
      } catch (error) {
        submit.addClass('disable');
        return;
      }
      submit.removeClass('disable');
    }

    inputTargetAddress.on("input", check);
    inputAmount.on("input", check);


    // Send token
    submit.click(function () {
      var targetAddress = ethers.utils.getAddress(inputTargetAddress.val());
      var amount = inputAmount.val();

      // https://ethgasstation.info/json/ethgasAPI.json
      // https://ethgasstation.info/gasrecs.php
      App.provider.getGasPrice().then((gasPrice) => {
        // gasPrice is a BigNumber; convert it to a decimal string
        gasPriceString = gasPrice.toString();

        console.log("Current gas price: " + gasPriceString);
      });

      App.contract.estimate.transfer(targetAddress, amount)
        .then(function (gas) {
          console.log("gas:" + gas);
        });


      // 必须关联一个有过签名钱包对象
      let contractWithSigner = App.contract.connect(App.activeWallet);
      //  发起交易，前面2个参数是函数的参数，第3个是交易参数
      contractWithSigner.transfer(targetAddress, amount, {
        gasLimit: 500000,
        // 偷懒，直接是用 2gwei
        gasPrice: ethers.utils.parseUnits("2", "gwei"),
      }).then(function (tx) {
        console.log(tx);

        App.addActivity('< Token sent: ' + tx.hash.substring(0, 20) + '...');
        alert('Success!');

        inputTargetAddress.val('');
        inputAmount.val('');
        submit.addClass('disable');

        App.refreshToken();
      }, function (error) {
        console.log(error);
        App.showError(error);
      });
    });
  }
}


App.init();

// 0x627306090abaB3A6e1400e9345bC60c78a8BEf57
// var privateKey = 'c87509a1c067bbde78beb793e6fa76530b6382a4c0241e5e4a9ec0a0f44dc0d3';
// App.setupWallet(new ethers.Wallet(privateKey));
