App = {
  web3Provider: null,
  contracts: {},
  account: '0x0',
  hasVoted: false,
  init: function() {
    return App.initWeb3();
  },

  initWeb3: function() {
    // TODO: refactor conditional
    if (typeof web3 !== 'undefined') {
      // If a web3 instance is already provided by Meta Mask.
      App.web3Provider = web3.currentProvider;
      ethereum.enable();
      web3 = new Web3(web3.currentProvider);
    } else {
      // Specify default instance if no web3 instance provided
      App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
      ethereum.enable();
      web3 = new Web3(App.web3Provider);
    }
    return App.initContract();
  },


  

  initContract: function() {
    $.getJSON("Zhongchou.json", function(election) {
      // 初始化合约
      App.contracts.Zhongchou = TruffleContract(election);
      // 连接与合约进行交互
      App.contracts.Zhongchou.setProvider(App.web3Provider);

      App.listenForEvents();

      return App.render();
    });
  },

  // 监听合约事件
  listenForEvents: function() {
    App.contracts.Zhongchou.deployed().then(function(instance) {



    });
  },
  
  render: function() {
  

    // // Load account data
    // web3.eth.getCoinbase(function(err, account) {
    //   if (err === null) {
    //     App.account = account;
    //     $("#accountAddress").html("地址: " + account);   
       

    //     web3.eth.getBalance( account,function(err,res){
    //       if(!err) {
    //           console.log(res);
    //           $("#accBalance").html("余额: " + res+'wei');   
    //       }else{
    //           console.log(err);
    //       }
    //   });


    //     }     
    // });


    // Load contract data
    App.contracts.Zhongchou.deployed().then(function(instance) {
      electionInstance = instance;
      return electionInstance.numCampaigns();
    }).then(function(numCampaigns) {
      var Powername = $("#Powername");
      Powername.empty();

      var Powernameall = $("#Powernameall");
      Powernameall.empty();
    

      for (var i = 1; i <= numCampaigns; i++) {
        electionInstance.campaigns(i).then(function(candidate) {
         // tag=false;


        
          var beneficiary = candidate[0];
          var bname = candidate[1];
          var description = candidate[2];
          var fundingGoal = candidate[3];
          var numFunders = candidate[4];
          var amount = candidate[5]/1000000000000000000;;
          var uid = candidate[6];

          if(	1e-10==amount){
            amount='当前项目已经终止0';
          }
          // Render candidate Result
          if(beneficiary!=0x0000000000000000000000000000000000000000){
            var candidateTemplate = "<tr>  <td><font size=4 >"+ uid + "</td>  <td width='100px'><font size=4 >" + beneficiary + "</td>  <td width='100px'><font size=4 >"+bname + "</td>    <td width='100px'><font size=4 >" +description + "</td>    <td width='100px'><font size=4 >"  + fundingGoal  +'ETH'+ "</td>    <td width='100px'><font size=4 >" + numFunders + "</td>    <td width='100px'><font size=4 >"+ amount +'ETH'+ "</td>  </tr>"
           
          }
          
          
          var qID=document.cookie.split(";")[0].split("=")[1]; 
           
          if(bname==qID){
            Powername.append(candidateTemplate);
          }
           
          Powernameall.append(candidateTemplate);
        
        });

      }
     
    
    
      //return electionInstance.voters(App.account);
    }).catch(function(error) {
      console.warn(error);
    });


   

 },


 quaryP: function() {
  qID= $('#qID').val();

  document.cookie="qID="+qID; 
 
 },





//   sendTransaction:function () {
//     var fromAccount = $('#fromAccount').val();
//     var toAccount = $('#toAccount').val();
//     var amount = $('#amount').val();

//     if (web3.isAddress(fromAccount) &&
//         web3.isAddress(toAccount) &&
//         amount != null && amount.length > 0
//     ) {
//         // Example 1: 使用Metamask 给的gas Limit 及 gas 价
//          var message = {from: fromAccount, to:toAccount, value: web3.toWei(amount, 'ether')};


//         web3.eth.sendTransaction(message, (err, res) => {
//         var output = "";
//         if (!err) {
//             output += res;
//         } else {
//             output = "Error";
//         }
//         document.getElementById('transactionResponse').innerHTML = "Transaction response= " + output + "<br />";
//         })
//     } else {
//         console.log("input error");
//     }
// },


newCampaign: function() {
  var pId= $('#pId').val();
  var pdec= $('#pdec').val();
  var pgoal= $('#pgoal').val();
 
  var userAccount = web3.eth.accounts[0];
  App.contracts.Zhongchou.deployed().then(function(instance) {
    return instance.newCampaign(pId, pdec,pgoal,{gas: 3000000,from: userAccount});
    
  }).then(function(result) {
    // Wait for to update
    console.log(accounts[0]); 
  }).catch(function(err) {
    console.error(err);
  });
},


 


 
overTheCampaign: function() {
  
  
  var opId= $('#opId').val();

  var userAccount = web3.eth.accounts[0];
  App.contracts.Zhongchou.deployed().then(function(instance) {
  return instance.finishoCampaign(opId, {gas: 3000000, from: userAccount});
    
  }).then(function(result) {
    // Wait for to update
  //  console.log(accounts[0]); 
  }).catch(function(err) {
    console.error(err);
  });
},
 
finishBet: function() {
  
  
  var pd= $('#pd').val();

  var userAccount = web3.eth.accounts[0];
  App.contracts.Zhongchou.deployed().then(function(instance) {
  return instance.checkGoalReached(pd, {gas: 3000000, from: userAccount});
    
  }).then(function(result) {
    // Wait for to update
  //  console.log(accounts[0]); 
  }).catch(function(err) {
    console.error(err);
  });
},



contribute: function() {
  
  
  var pids= $('#pids').val();
  var pprice= $('#pprice').val();
  
  var userAccount = web3.eth.accounts[0];
  App.contracts.Zhongchou.deployed().then(function(instance) {
  return instance.contribute(pids, {value:web3.toWei(pprice, 'ether'),gas: 3000000, from: userAccount});
    
  }).then(function(result) {
    // Wait for to update
  //  console.log(accounts[0]); 
  }).catch(function(err) {
    console.error(err);
  });
},






};

$(function() {
  $(window).load(function() {
    App.init();
  });
});