App = {
  web3Provider: null,
  contracts: {},
  account: '0x0',
  init: function() {
    return App.initWeb3();
  },

  initWeb3: function() {
    // TODO: refactor conditional
    if (typeof web3 !== 'undefined') {
      // If a web3 instance is already provided by Meta Mask.
      App.web3Provider = web3.currentProvider;
      ethereum.enable();
      web3 = new Web3(web3.currentProvider);
    } else {
      // Specify default instance if no web3 instance provided
      App.web3Provider = new Web3.providers.HttpProvider('http://localhost:7545');
      ethereum.enable();
      web3 = new Web3(App.web3Provider);
    }
    return App.initContract();
  },


  

  initContract: function() {
    $.getJSON("Election.json", function(election) {
      // 初始化合约
      App.contracts.Election = TruffleContract(election);
      // 连接与合约进行交互
      App.contracts.Election.setProvider(App.web3Provider);

      App.listenForEvents();
    //  App.allCreated();
     // App.capacity();
      return App.render();
    });
  },

  // 监听合约事件
  listenForEvents: function() {
    App.contracts.Election.deployed().then(function(instance) {



    });
  },
  




  
  render: function() {
  
 
    // Load account data
    web3.eth.getCoinbase(function(err, account) {
      if (err === null) {
        App.account = account;
        $("#accountAddress").html("当前区块链地址: " + account);   
      

        web3.eth.getBalance( account,function(err,res){
          if(!err) {
              console.log(res);
              $("#accBalance").html("当前地址余额: " + res+'wei');   
          }else{
              console.log(err);
          }
      });


        }     
    });
 
   


         // Load contract data
         App.contracts.Election.deployed().then(function(instance) {
          electionInstance = instance;
          return electionInstance._capacity();
        }).then(function(_capacity) {
          var Powernamea = $("#allproducts");
          Powernamea.empty();
    
           
        

          for (var i = 1; i <= _capacity; i++) {
            electionInstance.productnews(i).then(function(candidate) {
    
            
              var id = candidate[0];
              var nums = candidate[1];
              var createTime = candidate[2];
              var nowhold = candidate[3];
              var createMan = candidate[4];
              var names = candidate[5];
              var ttime = candidate[6];
              var befhold = candidate[7];

              var unixTimestamp = new Date(createTime*1000);
              var createTime = unixTimestamp.toLocaleString();

              var unixTimestamp = new Date(ttime*1000);
              var ttime = unixTimestamp.toLocaleString();
              // Render candidate Result
              var candidateTemplate = "<tr><td><img src='../images/"+id+".jpg' height='100px' width='100px' /></td>  <td>" + id + "</td>  <td>" +names + "</td>  <td>" +createTime + "</td>  <td>" +ttime + "</td>  <td>"  + nowhold  + "</td>  <td>" + befhold  + "</td>  <td>" + createMan + "</td>  <td>" +nums + "</td>  </tr>"
              
                
              var qIDcx=document.cookie.split(";")[0].split("=")[1]; 
           
               //  if(nums==qIDcx){
                  Powernamea.append(candidateTemplate);
           //  }
            
            });

          }
         
        
        
          //return electionInstance.voters(App.account);
        }).catch(function(error) {
          console.warn(error);
        });




 


   

 },



 quaryP: function() {
  qIDcx= $('#qIDcx').val();

  document.cookie="qIDcx="+qIDcx; 
 
 },




};

$(function() {
  $(window).load(function() {
    App.init();
  });
});